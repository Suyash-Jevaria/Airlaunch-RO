using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using ROStandaloneAirlaunch;

namespace ROStandaloneAirlaunch.Tests
{
    [TestFixture]
    public class AirlaunchSettingsTests
    {
        private static AirlaunchSettings Acceptance()
        {
            return new AirlaunchSettings { Altitude = 12000, Speed = 350, Heading = 90, Pitch = 0 };
        }

        [Test]
        public void AcceptancePreset_IsValid()
        {
            string err;
            Assert.That(Acceptance().Validate(new AirlaunchLimits(), out err), Is.True, err);
            Assert.That(err, Is.Null);
        }

        [TestCase("Altitude", 50.0)]
        [TestCase("Altitude", 200000.0)]
        [TestCase("Speed", -1.0)]
        [TestCase("Speed", 5000.0)]
        [TestCase("Heading", 360.0)]
        [TestCase("Heading", -1.0)]
        [TestCase("Pitch", 91.0)]
        [TestCase("Throttle", 1.5)]
        [TestCase("HoldSeconds", -1.0)]
        [TestCase("HoldSeconds", 31.0)]
        [TestCase("DistanceKm", -5.0)]
        [TestCase("Bearing", 400.0)]
        [TestCase("Altitude", double.NaN)]
        public void OutOfRange_IsRejected(string field, double value)
        {
            AirlaunchSettings s = Acceptance();
            typeof(AirlaunchSettings).GetField(field).SetValue(s, value);
            string err;
            Assert.That(s.Validate(new AirlaunchLimits(), out err), Is.False);
            Assert.That(err, Is.Not.Null.And.Not.Empty);
        }

        [Test]
        public void LatLonMode_ChecksLatitudeAndLongitude()
        {
            string err;
            var s = Acceptance();
            s.Mode = PositionMode.LatLon;
            s.Latitude = 90; // exact pole: heading undefined
            Assert.That(s.Validate(new AirlaunchLimits(), out err), Is.False);
            s.Latitude = 45; s.Longitude = 181;
            Assert.That(s.Validate(new AirlaunchLimits(), out err), Is.False);
            s.Longitude = -122.3;
            Assert.That(s.Validate(new AirlaunchLimits(), out err), Is.True, err);
            // Offset fields are ignored in LatLon mode.
            s.DistanceKm = -1;
            Assert.That(s.Validate(new AirlaunchLimits(), out err), Is.True, err);
        }

        [Test]
        public void Limits_FromConfigValues()
        {
            var l = AirlaunchLimits.FromValues(new Dictionary<string, string>
            {
                { "maxAltitude", "20000" }, { "terrainClearance", "300" }, { "maxSpeed", "garbage" }
            });
            Assert.That(l.MaxAltitude, Is.EqualTo(20000));
            Assert.That(l.TerrainClearance, Is.EqualTo(300));
            Assert.That(l.MaxSpeed, Is.EqualTo(new AirlaunchLimits().MaxSpeed)); // malformed -> default
            string err;
            var s = Acceptance();
            s.Altitude = 25000;
            Assert.That(s.Validate(l, out err), Is.False);
        }

        [Test]
        public void ToValues_FromValues_RoundTrip()
        {
            var s = new AirlaunchSettings
            {
                Name = "x", Mode = PositionMode.LatLon, DistanceKm = 12.5, Bearing = 45, Latitude = -33.9, Longitude = 151.2,
                Altitude = 9876.5, Speed = 123.456, Heading = 271, Pitch = -3, VelocityFollowsPitch = true,
                Throttle = 0.42, RetractGear = false, StageOnRelease = false, HoldSeconds = 2.5
            };
            AirlaunchSettings r = AirlaunchSettings.FromValues(s.ToValues());
            foreach (var f in typeof(AirlaunchSettings).GetFields())
                Assert.That(f.GetValue(r), Is.EqualTo(f.GetValue(s)), f.Name);
        }

        [Test]
        public void FromValues_PartialKeepsBase_AndParsesModeCaseInsensitive()
        {
            var baseS = Acceptance();
            baseS.Throttle = 0.3;
            var r = AirlaunchSettings.FromValues(new Dictionary<string, string> { { "speed", "250" }, { "mode", "latlon" } }, baseS);
            Assert.That(r.Speed, Is.EqualTo(250));
            Assert.That(r.Altitude, Is.EqualTo(12000));
            Assert.That(r.Throttle, Is.EqualTo(0.3));
            Assert.That(r.Mode, Is.EqualTo(PositionMode.LatLon));
            Assert.That(baseS.Speed, Is.EqualTo(350), "base must not be mutated");
        }

        [Test]
        public void ShippedConfig_ContainsAcceptancePreset()
        {
            // Light text check of the shipped cfg (ConfigNode parsing needs KSP, so it isn't used here).
            string dir = TestContext.CurrentContext.TestDirectory;
            string cfg = Path.GetFullPath(Path.Combine(dir, "..", "..", "..", "..", "..",
                "GameData", "ROStandaloneAirlaunch", "PluginData", "AirlaunchSettings.cfg"));
            Assert.That(File.Exists(cfg), Is.True, cfg);
            string text = File.ReadAllText(cfg);
            StringAssert.Contains("ROSTANDALONE_AIRLAUNCH", text);
            StringAssert.Contains("altitude = 12000", text);
            StringAssert.Contains("speed = 350", text);
            StringAssert.Contains("heading = 90", text);
            Assert.That(text.Split('{').Length, Is.EqualTo(text.Split('}').Length), "unbalanced braces");
        }
    }
}

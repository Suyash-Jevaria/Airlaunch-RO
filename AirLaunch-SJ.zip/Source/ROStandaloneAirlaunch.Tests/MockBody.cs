using System;
using ROStandaloneAirlaunch;

namespace ROStandaloneAirlaunch.Tests
{
    /// <summary>
    /// Spherical stand-in for a KSP CelestialBody. Spin axis is +Z; lat/lon map to positions the same
    /// way for any handedness, and <see cref="Mirrored"/> flips X to emulate a left-handed (Unity) frame.
    /// </summary>
    public class MockBody
    {
        // RSS Earth
        public const double EarthRadius = 6371000.0;
        public const double EarthSiderealDay = 86164.098903691;

        public double Radius = EarthRadius;
        public Vec3d Center = new Vec3d(1.0e7, -3.0e6, 2.5e5);   // deliberately not at the origin
        public double AngularSpeed = 2 * Math.PI / EarthSiderealDay;
        public bool Mirrored;

        public Vec3d SurfacePosition(double latDeg, double lonDeg, double alt)
        {
            double phi = latDeg * AirlaunchMath.Deg2Rad, lambda = lonDeg * AirlaunchMath.Deg2Rad;
            double r = Radius + alt;
            var local = new Vec3d(r * Math.Cos(phi) * Math.Cos(lambda), r * Math.Cos(phi) * Math.Sin(lambda), r * Math.Sin(phi));
            if (Mirrored) local.X = -local.X;
            return Center + local;
        }

        /// <summary>Angular velocity vector such that the surface moves towards +longitude (east).</summary>
        public Vec3d AngularVelocity
        {
            get { return new Vec3d(0, 0, Mirrored ? -AngularSpeed : AngularSpeed); }
        }

        /// <summary>Velocity of the rotating frame at a world position (KSP: CelestialBody.getRFrmVel).
        /// The cross product here is right-handed, so a mirrored frame flips omega to keep the motion eastward.</summary>
        public Vec3d FrameVelocity(Vec3d worldPos)
        {
            return Vec3d.Cross(AngularVelocity, worldPos - Center);
        }

        public LocalBasis Basis(double latDeg, double lonDeg)
        {
            return AirlaunchMath.ComputeLocalBasis((la, lo) => SurfacePosition(la, lo, 0), Center, latDeg, lonDeg);
        }

        /// <summary>Inverse mapping for the tests: world position -> lat/lon.</summary>
        public void LatLon(Vec3d worldPos, out double latDeg, out double lonDeg)
        {
            Vec3d l = worldPos - Center;
            if (Mirrored) l.X = -l.X;
            latDeg = Math.Asin(l.Z / l.Magnitude) * AirlaunchMath.Rad2Deg;
            lonDeg = Math.Atan2(l.Y, l.X) * AirlaunchMath.Rad2Deg;
        }
    }
}

using System;
using NUnit.Framework;
using ROStandaloneAirlaunch;

namespace ROStandaloneAirlaunch.Tests
{
    [TestFixture]
    public class AirlaunchMathTests
    {
        // KSC (RSS, Cape Canaveral LC-39 area)
        private const double KscLat = 28.608;
        private const double KscLon = -80.604;

        private static MockBody[] Bodies()
        {
            return new[] { new MockBody(), new MockBody { Mirrored = true } };
        }

        [TestCaseSource(nameof(Bodies))]
        public void AcceptanceCase_RssEarth_12km_350ms_East(MockBody earth)
        {
            const double alt = 12000, speed = 350, heading = 90, pitch = 0;

            Vec3d pos = earth.SurfacePosition(KscLat, KscLon, alt);
            LocalBasis b = earth.Basis(KscLat, KscLon);
            Vec3d surf = AirlaunchMath.SurfaceVelocity(b, heading, pitch, speed);
            Vec3d frame = earth.FrameVelocity(pos);
            Vec3d inertial = AirlaunchMath.InertialVelocity(frame, surf);

            // Altitude above sea level (datum radius).
            Assert.That((pos - earth.Center).Magnitude - earth.Radius, Is.EqualTo(alt).Within(1e-6));

            // Surface-relative velocity recovered the way KSP does it (obt - frame) is exactly 350 m/s due east.
            Vec3d recovered = inertial - frame;
            Assert.That(recovered.Magnitude, Is.EqualTo(speed).Within(1e-9));
            Assert.That(AirlaunchMath.HeadingOf(b, recovered), Is.EqualTo(90.0).Within(1e-6));
            Assert.That(Vec3d.Dot(recovered, b.Up), Is.EqualTo(0.0).Within(1e-9));

            // Earth's rotation is added: frame velocity points east, inertial speed ~ 350 + omega (R+h) cos(lat).
            Assert.That(Vec3d.Dot(frame.Normalized, b.East), Is.EqualTo(1.0).Within(1e-9));
            double rotSpeed = earth.AngularSpeed * (earth.Radius + alt) * Math.Cos(KscLat * AirlaunchMath.Deg2Rad);
            Assert.That(rotSpeed, Is.EqualTo(408.6).Within(0.5));
            Assert.That(inertial.Magnitude, Is.EqualTo(speed + rotSpeed).Within(1e-6));
        }

        [TestCaseSource(nameof(Bodies))]
        public void WestboundLaunch_SubtractsRotation(MockBody earth)
        {
            Vec3d pos = earth.SurfacePosition(KscLat, KscLon, 12000);
            LocalBasis b = earth.Basis(KscLat, KscLon);
            Vec3d inertial = AirlaunchMath.InertialVelocity(earth.FrameVelocity(pos), AirlaunchMath.SurfaceVelocity(b, 270, 0, 350));
            double rotSpeed = earth.FrameVelocity(pos).Magnitude;
            Assert.That(inertial.Magnitude, Is.EqualTo(rotSpeed - 350).Within(1e-6));
        }

        [Test]
        public void LocalBasis_IsOrthonormal_Everywhere(
            [Values(-89.9, -45, 0, 28.608, 60, 89.0, 89.9)] double lat,
            [Values(-180, -80.604, 0, 90, 179.999)] double lon,
            [Values(false, true)] bool mirrored)
        {
            var body = new MockBody { Mirrored = mirrored };
            LocalBasis b = body.Basis(lat, lon);
            Assert.That(b.East.Magnitude, Is.EqualTo(1).Within(1e-9));
            Assert.That(b.North.Magnitude, Is.EqualTo(1).Within(1e-9));
            Assert.That(b.Up.Magnitude, Is.EqualTo(1).Within(1e-9));
            Assert.That(Vec3d.Dot(b.East, b.North), Is.EqualTo(0).Within(1e-9));
            Assert.That(Vec3d.Dot(b.East, b.Up), Is.EqualTo(0).Within(1e-9));
            Assert.That(Vec3d.Dot(b.North, b.Up), Is.EqualTo(0).Within(1e-9));
        }

        [Test]
        public void Headings_MoveTowardsTheRightCompassDirection([Values(false, true)] bool mirrored)
        {
            var body = new MockBody { Mirrored = mirrored };
            Vec3d p = body.SurfacePosition(KscLat, KscLon, 0);
            LocalBasis b = body.Basis(KscLat, KscLon);
            double lat, lon;

            body.LatLon(p + AirlaunchMath.HeadingVector(b, 0) * 100, out lat, out lon);
            Assert.That(lat, Is.GreaterThan(KscLat));
            Assert.That(lon, Is.EqualTo(KscLon).Within(1e-6));

            body.LatLon(p + AirlaunchMath.HeadingVector(b, 90) * 100, out lat, out lon);
            Assert.That(lon, Is.GreaterThan(KscLon));
            Assert.That(lat, Is.EqualTo(KscLat).Within(1e-5));

            body.LatLon(p + AirlaunchMath.HeadingVector(b, 180) * 100, out lat, out lon);
            Assert.That(lat, Is.LessThan(KscLat));

            body.LatLon(p + AirlaunchMath.HeadingVector(b, 270) * 100, out lat, out lon);
            Assert.That(lon, Is.LessThan(KscLon));
        }

        [Test]
        public void Attitude_NoseAndBelly(
            [Values(0, 45, 90, 135, 270, 359)] double heading,
            [Values(-30, 0, 5, 45, 80)] double pitch)
        {
            var body = new MockBody();
            LocalBasis b = body.Basis(KscLat, KscLon);
            Vec3d nose, belly;
            AirlaunchMath.AttitudeAxes(b, heading, pitch, out nose, out belly);

            Assert.That(nose.Magnitude, Is.EqualTo(1).Within(1e-9));
            Assert.That(belly.Magnitude, Is.EqualTo(1).Within(1e-9));
            Assert.That(Vec3d.Dot(nose, belly), Is.EqualTo(0).Within(1e-9));
            // Elevation of the nose equals pitch.
            Assert.That(Math.Asin(Vec3d.Dot(nose, b.Up)) * AirlaunchMath.Rad2Deg, Is.EqualTo(pitch).Within(1e-6));
            // Nose points along the heading.
            Assert.That(AirlaunchMath.HeadingDifference(AirlaunchMath.HeadingOf(b, nose), heading), Is.EqualTo(0).Within(1e-6));
            // Belly points down (wings level, upright).
            Assert.That(Vec3d.Dot(belly, b.Up), Is.LessThan(0));
            // Zero roll: the belly lies in the vertical plane containing the nose.
            Vec3d side = Vec3d.Cross(b.Up, AirlaunchMath.HeadingVector(b, heading));
            Assert.That(Vec3d.Dot(belly, side), Is.EqualTo(0).Within(1e-9));
        }

        [Test]
        public void VelocityFollowsPitch_RaisesVelocityVector()
        {
            var body = new MockBody();
            LocalBasis b = body.Basis(0, 0);
            Vec3d v = AirlaunchMath.SurfaceVelocity(b, 90, 10, 350);
            Assert.That(v.Magnitude, Is.EqualTo(350).Within(1e-9));
            Assert.That(Vec3d.Dot(v, b.Up), Is.EqualTo(350 * Math.Sin(10 * AirlaunchMath.Deg2Rad)).Within(1e-9));
        }

        [Test]
        public void Destination_QuarterCircleEastFromEquator()
        {
            double lat, lon, fb;
            double quarter = Math.PI / 2 * MockBody.EarthRadius;
            AirlaunchMath.Destination(0, 0, quarter, 90, MockBody.EarthRadius, out lat, out lon, out fb);
            Assert.That(lat, Is.EqualTo(0).Within(1e-9));
            Assert.That(lon, Is.EqualTo(90).Within(1e-9));
            Assert.That(fb, Is.EqualTo(90).Within(1e-6));
        }

        [Test]
        public void Destination_ZeroDistanceIsStartPoint()
        {
            double lat, lon, fb;
            AirlaunchMath.Destination(KscLat, KscLon, 0, 123, MockBody.EarthRadius, out lat, out lon, out fb);
            Assert.That(lat, Is.EqualTo(KscLat).Within(1e-12));
            Assert.That(lon, Is.EqualTo(KscLon).Within(1e-12));
            Assert.That(fb, Is.EqualTo(123).Within(1e-12));
        }

        [Test]
        public void Destination_RoundTripsDistanceAndBearing(
            [Values(0.5, 20, 500, 5000)] double km,
            [Values(0, 37, 90, 200, 315)] double bearing)
        {
            double lat, lon, fb;
            AirlaunchMath.Destination(KscLat, KscLon, km * 1000, bearing, MockBody.EarthRadius, out lat, out lon, out fb);
            double d = AirlaunchMath.GreatCircleDistance(KscLat, KscLon, lat, lon, MockBody.EarthRadius);
            Assert.That(d, Is.EqualTo(km * 1000).Within(1e-3 + km * 1e-6));
            Assert.That(AirlaunchMath.HeadingDifference(AirlaunchMath.InitialBearing(KscLat, KscLon, lat, lon), bearing),
                        Is.EqualTo(0).Within(1e-6));
        }

        [Test]
        public void Destination_CrossesDateLine()
        {
            double lat, lon, fb;
            AirlaunchMath.Destination(0, 179.9, 50000, 90, MockBody.EarthRadius, out lat, out lon, out fb);
            Assert.That(lon, Is.LessThan(-179.0));
            Assert.That(lon, Is.GreaterThanOrEqualTo(-180.0));
        }

        [TestCaseSource(nameof(Bodies))]
        public void HoldTrack_KeepsAltitudeAndSurfaceSpeedConstant(MockBody earth)
        {
            // The 10 s RP-1-style countdown: the vessel must not sink or slow down during the hold.
            var start = new TrackPoint(KscLat, KscLon, 12000, 90);
            const double speed = 350, dt = 0.02;
            for (double t = 0; t < 10; t += 0.5)
            {
                TrackPoint a = AirlaunchMath.TrackAt(start, speed, 0, earth.Radius, t);
                TrackPoint c = AirlaunchMath.TrackAt(start, speed, 0, earth.Radius, t + dt);
                Assert.That(a.Altitude, Is.EqualTo(12000).Within(1e-9));

                // In the body-fixed frame, the finite-difference velocity is the surface velocity.
                Vec3d pa = earth.SurfacePosition(a.Latitude, a.Longitude, a.Altitude);
                Vec3d pc = earth.SurfacePosition(c.Latitude, c.Longitude, c.Altitude);
                Vec3d v = (pc - pa) / dt;
                Assert.That(v.Magnitude, Is.EqualTo(speed).Within(1e-3));

                // And it flies the commanded heading (great-circle heading at that point).
                LocalBasis b = earth.Basis(a.Latitude, a.Longitude);
                Assert.That(AirlaunchMath.HeadingDifference(AirlaunchMath.HeadingOf(b, v), a.Heading), Is.EqualTo(0).Within(1e-3));
            }
            TrackPoint end = AirlaunchMath.TrackAt(start, speed, 0, earth.Radius, 10);
            Assert.That(AirlaunchMath.GreatCircleDistance(KscLat, KscLon, end.Latitude, end.Longitude, earth.Radius + 12000),
                        Is.EqualTo(3500).Within(1e-3));
        }

        [Test]
        public void HoldTrack_ClimbsWhenVelocityFollowsPitch()
        {
            var start = new TrackPoint(0, 0, 10000, 90);
            TrackPoint p = AirlaunchMath.TrackAt(start, 300, 30, MockBody.EarthRadius, 2);
            Assert.That(p.Altitude, Is.EqualTo(10000 + 300 * 0.5 * 2).Within(1e-6));
        }

        [TestCase(370, 10)]
        [TestCase(-90, 270)]
        [TestCase(720, 0)]
        public void NormalizeDegrees(double input, double expected)
        {
            Assert.That(AirlaunchMath.NormalizeDegrees(input), Is.EqualTo(expected).Within(1e-12));
        }

        [TestCase(10, 350, 20)]
        [TestCase(350, 10, -20)]
        [TestCase(180, 0, 180)]
        public void HeadingDifference(double a, double b, double expected)
        {
            Assert.That(AirlaunchMath.HeadingDifference(a, b), Is.EqualTo(expected).Within(1e-12));
        }

        [TestCase(190, -170)]
        [TestCase(-180, 180)]
        [TestCase(-80.604, -80.604)]
        public void NormalizeLongitude(double input, double expected)
        {
            Assert.That(AirlaunchMath.NormalizeLongitude(input), Is.EqualTo(expected).Within(1e-9));
        }
    }
}

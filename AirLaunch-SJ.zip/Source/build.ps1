<#
  ROStandaloneAirlaunch build script (Windows PowerShell 5.1+).

    1. builds the plugin (Release) against KSP assemblies in -KSPManagedDir
    2. runs the unit tests
    3. checks the built DLL references nothing from RP-1 / KCT / ROUtils / Harmony
    4. packages dist\ROStandaloneAirlaunch-<version>.zip

  It never reads or writes a KSP installation. KSP's DLLs must be copied into -KSPManagedDir
  manually (see README.md, "Building").
#>
param(
    [string]$KSPManagedDir = (Join-Path $PSScriptRoot '..\References'),
    [string]$Version = '1.0.0',
    [switch]$SkipTests
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$src = Join-Path $root 'Source'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_NOLOGO = '1'

$dotnet = Join-Path $root '.dotnet\dotnet.exe'
if (-not (Test-Path $dotnet)) { $dotnet = 'dotnet' }

function Invoke-Dotnet {
    & $dotnet @args
    if ($LASTEXITCODE -ne 0) { throw "dotnet $($args -join ' ') failed with exit code $LASTEXITCODE" }
}

if (-not (Test-Path (Join-Path $KSPManagedDir 'Assembly-CSharp.dll'))) {
    throw "KSP assemblies not found in '$KSPManagedDir'. See README.md (Building)."
}
$KSPManagedDir = (Resolve-Path $KSPManagedDir).Path

Write-Host '== Building plugin'
Invoke-Dotnet build (Join-Path $src 'ROStandaloneAirlaunch\ROStandaloneAirlaunch.csproj') -c Release -nologo "-p:KSPManagedDir=$KSPManagedDir"
$dll = Join-Path $root 'GameData\ROStandaloneAirlaunch\Plugins\ROStandaloneAirlaunch.dll'
if (-not (Test-Path $dll)) { throw "Expected build output missing: $dll" }

if (-not $SkipTests) {
    Write-Host '== Running unit tests'
    Invoke-Dotnet test (Join-Path $src 'ROStandaloneAirlaunch.Tests\ROStandaloneAirlaunch.Tests.csproj') -nologo
}

Write-Host '== Checking assembly references'
Invoke-Dotnet build (Join-Path $src 'Tools\ApiInspector\ApiInspector.csproj') -c Release -nologo -v q
$inspector = Join-Path $src 'Tools\ApiInspector\bin\Release\net8.0\ApiInspector.dll'
$refs = & $dotnet $inspector refs $dll
$refs | ForEach-Object { Write-Host "   $_" }
$allowed = '^(mscorlib|System(\..+)?|netstandard|Assembly-CSharp|Assembly-CSharp-firstpass|UnityEngine(\..+)?) '
$bad = $refs | Where-Object { $_ -notmatch $allowed }
if ($bad) { throw "Unexpected assembly references: $($bad -join ', ')" }
if ($refs -match '(?i)(RP0|RP-1|KerbalConstructionTime|KCT|ROUtils|Harmony)') { throw 'Plugin references RP-1/KCT/ROUtils/Harmony' }

Write-Host '== Packaging'
$dist = Join-Path $root 'dist'
$stage = Join-Path $dist 'stage\ROStandaloneAirlaunch'
if (Test-Path (Join-Path $dist 'stage')) { Remove-Item (Join-Path $dist 'stage') -Recurse -Force -Confirm:$false }
New-Item -ItemType Directory -Force (Join-Path $stage 'GameData\ROStandaloneAirlaunch\Plugins') | Out-Null
New-Item -ItemType Directory -Force (Join-Path $stage 'GameData\ROStandaloneAirlaunch\PluginData') | Out-Null

Copy-Item $dll (Join-Path $stage 'GameData\ROStandaloneAirlaunch\Plugins\')
Copy-Item (Join-Path $root 'GameData\ROStandaloneAirlaunch\PluginData\AirlaunchSettings.cfg') (Join-Path $stage 'GameData\ROStandaloneAirlaunch\PluginData\')
Copy-Item (Join-Path $root 'GameData\ROStandaloneAirlaunch\ROStandaloneAirlaunch.version') (Join-Path $stage 'GameData\ROStandaloneAirlaunch\')
Copy-Item (Join-Path $root 'LICENSE') $stage
Copy-Item (Join-Path $root 'README.md') $stage
# Mod folder gets its own copy of the license so it travels with the installed files.
Copy-Item (Join-Path $root 'LICENSE') (Join-Path $stage 'GameData\ROStandaloneAirlaunch\LICENSE.txt')

# Source: everything under Source\ except build output.
$srcStage = Join-Path $stage 'Source'
Get-ChildItem $src -Recurse -File | Where-Object { $_.FullName -notmatch '\\(bin|obj)\\' } | ForEach-Object {
    $rel = $_.FullName.Substring($src.Length + 1)
    $dest = Join-Path $srcStage $rel
    New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
    Copy-Item $_.FullName $dest
}
Copy-Item (Join-Path $root 'global.json') $srcStage

# Never ship KSP/Unity assemblies or any DLL other than the plugin.
$dlls = Get-ChildItem $stage -Recurse -Filter *.dll
if ($dlls.Count -ne 1 -or $dlls[0].Name -ne 'ROStandaloneAirlaunch.dll') { throw "Unexpected DLLs in package: $($dlls.Name -join ', ')" }

$zip = Join-Path $dist "ROStandaloneAirlaunch-$Version.zip"
if (Test-Path $zip) { Remove-Item $zip -Force -Confirm:$false }
Compress-Archive -Path $stage -DestinationPath $zip
Remove-Item (Join-Path $dist 'stage') -Recurse -Force -Confirm:$false
Write-Host "== Done: $zip"

using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices;

// Usage:
//   ApiInspector members <refDir> "Type||regex" ...   -> dump matching member signatures
//   ApiInspector refs <assembly.dll>                     -> list referenced assemblies
//   ApiInspector version <refDir>                        -> read KSP version from Versioning..cctor IL
static class Program
{
    static int Main(string[] args)
    {
        if (args.Length < 2) { Console.Error.WriteLine("bad args"); return 2; }
        switch (args[0])
        {
            case "refs": return Refs(args[1]);
            case "members": return Members(args[1], args.Skip(2));
            case "version": return Version(args[1]);
        }
        return 2;
    }

    static int Refs(string path)
    {
        using var pe = new PEReader(File.OpenRead(path));
        var md = pe.GetMetadataReader();
        foreach (var h in md.AssemblyReferences)
        {
            var r = md.GetAssemblyReference(h);
            Console.WriteLine($"{md.GetString(r.Name)} {r.Version}");
        }
        return 0;
    }

    static MetadataLoadContext Ctx(string refDir)
    {
        var paths = Directory.GetFiles(refDir, "*.dll").ToList();
        paths.AddRange(Directory.GetFiles(RuntimeEnvironment.GetRuntimeDirectory(), "*.dll"));
        return new MetadataLoadContext(new PathAssemblyResolver(paths), "System.Private.CoreLib");
    }

    static int Members(string refDir, IEnumerable<string> specs)
    {
        using var ctx = Ctx(refDir);
        var asm = ctx.LoadFromAssemblyPath(Path.Combine(refDir, "Assembly-CSharp.dll"));
        const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly;
        foreach (var spec in specs)
        {
            var parts = spec.Split("||", 2);
            Type t = asm.GetType(parts[0]);
            if (t == null) { Console.WriteLine($"NO TYPE {parts[0]}"); continue; }
            var rx = new System.Text.RegularExpressions.Regex(parts.Length > 1 ? parts[1] : ".");
            foreach (var m in t.GetMembers(all))
            {
                if (!rx.IsMatch(m.Name)) continue;
                string s;
                try { s = Describe(m); } catch (Exception e) { s = $"{m.Name} <{e.GetType().Name}>"; }
                Console.WriteLine($"{t.FullName} :: {s}");
            }
        }
        return 0;
    }

    static string Vis(MethodBase mb) => mb == null ? "" : (mb.IsPublic ? "public " : "nonpublic ") + (mb.IsStatic ? "static " : "");

    static string Describe(MemberInfo m) => m switch
    {
        MethodInfo mi => $"{Vis(mi)}method {mi.ReturnType.Name} {mi.Name}({string.Join(", ", mi.GetParameters().Select(p => p.ParameterType.Name + " " + p.Name + (p.HasDefaultValue ? "=" + (p.RawDefaultValue ?? "null") : "")))})",
        FieldInfo fi => $"{(fi.IsPublic ? "public " : "nonpublic ")}{(fi.IsStatic ? "static " : "")}field {fi.FieldType.Name} {fi.Name}",
        PropertyInfo pi => $"{Vis(pi.GetMethod)}property {pi.PropertyType.Name} {pi.Name} {{{(pi.GetMethod != null ? "get;" : "")}{(pi.SetMethod != null ? (pi.SetMethod.IsPublic ? "set;" : "nonpublic set;") : "")}}}",
        ConstructorInfo ci => $"{Vis(ci)}ctor({string.Join(", ", ci.GetParameters().Select(p => p.ParameterType.Name))})",
        EventInfo ei => $"event {ei.EventHandlerType?.Name} {ei.Name}",
        Type nt => $"nested type {nt.Name}",
        _ => m.ToString()
    };

    // Versioning's static fields are assigned in its static constructor; read the ldc.i4 constants.
    static int Version(string refDir)
    {
        using var ctx = Ctx(refDir);
        var asm = ctx.LoadFromAssemblyPath(Path.Combine(refDir, "Assembly-CSharp.dll"));
        var t = asm.GetType("Versioning");
        if (t == null) { Console.WriteLine("no Versioning type"); return 1; }
        var cctor = t.TypeInitializer;
        var il = cctor?.GetMethodBody()?.GetILAsByteArray();
        if (il == null) { Console.WriteLine("no cctor"); return 1; }
        var module = t.Module;
        // Pattern scan: "ldc.i4.x | ldc.i4.s n | ldc.i4 n" immediately followed by "stsfld <token>".
        // The resolved field name filters out accidental byte matches.
        for (int i = 0; i + 5 < il.Length; i++)
        {
            if (il[i] != 0x80) continue;
            int? val = null;
            if (i >= 1 && il[i - 1] >= 0x16 && il[i - 1] <= 0x1E) val = il[i - 1] - 0x16;
            else if (i >= 2 && il[i - 2] == 0x1F) val = (sbyte)il[i - 1];
            else if (i >= 5 && il[i - 5] == 0x20) val = BitConverter.ToInt32(il, i - 4);
            if (val == null) continue;
            FieldInfo f = null;
            try { f = module.ResolveField(BitConverter.ToInt32(il, i + 1)); } catch { }
            if (f != null && f.DeclaringType == t && f.Name.StartsWith("version_"))
                Console.WriteLine($"{f.Name}={val}");
        }
        return 0;
    }
}

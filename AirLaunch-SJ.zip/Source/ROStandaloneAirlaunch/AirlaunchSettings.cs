// ROStandaloneAirlaunch - CC BY-NC-SA 4.0. See LICENSE.
// Pure settings model (no KSP types) so validation and parsing are unit testable.
// Replaces RP-1's AirlaunchParams + AirlaunchTechLevel: limits come from a config file
// instead of the tech tree, so there's no research gating.

using System;
using System.Collections.Generic;
using System.Globalization;

namespace ROStandaloneAirlaunch
{
    public enum PositionMode
    {
        /// <summary>Distance + bearing from wherever the vessel spawned (runway or pad). RP-1's model.</summary>
        LaunchSiteOffset,
        /// <summary>Absolute latitude / longitude on the launch body.</summary>
        LatLon
    }

    public class AirlaunchLimits
    {
        public double MinAltitude = 100;          // m ASL
        public double MaxAltitude = 100000;       // m ASL
        public double MinSpeed = 0;               // m/s surface-relative
        public double MaxSpeed = 3000;            // m/s surface-relative
        public double MaxDistanceKm = 20000;
        public double TerrainClearance = 150;     // m required above terrain at the target point
        public double MaxHoldSeconds = 30;

        public static AirlaunchLimits FromValues(IDictionary<string, string> values)
        {
            var l = new AirlaunchLimits();
            if (values == null) return l;
            l.MinAltitude = Read(values, "minAltitude", l.MinAltitude);
            l.MaxAltitude = Read(values, "maxAltitude", l.MaxAltitude);
            l.MinSpeed = Read(values, "minSpeed", l.MinSpeed);
            l.MaxSpeed = Read(values, "maxSpeed", l.MaxSpeed);
            l.MaxDistanceKm = Read(values, "maxDistanceKm", l.MaxDistanceKm);
            l.TerrainClearance = Read(values, "terrainClearance", l.TerrainClearance);
            l.MaxHoldSeconds = Read(values, "maxHoldSeconds", l.MaxHoldSeconds);
            return l;
        }

        internal static double Read(IDictionary<string, string> values, string key, double fallback)
        {
            string s;
            double d;
            if (values.TryGetValue(key, out s) &&
                double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d) &&
                !double.IsNaN(d) && !double.IsInfinity(d))
                return d;
            return fallback;
        }
    }

    public class AirlaunchSettings
    {
        public string Name = "";
        public PositionMode Mode = PositionMode.LaunchSiteOffset;
        public double DistanceKm = 0;
        public double Bearing = 90;
        public double Latitude = 28.608;          // Cape Canaveral area, RSS
        public double Longitude = -80.604;
        /// <summary>Altitude above sea level (above the body's datum radius), not above terrain.</summary>
        public double Altitude = 12000;
        /// <summary>Speed relative to the rotating surface (what the navball shows in Surface mode).</summary>
        public double Speed = 350;
        public double Heading = 90;
        public double Pitch = 0;
        /// <summary>When true, the velocity vector is raised by the pitch angle (zero angle of attack).
        /// When false (default), the velocity is horizontal and pitch only sets attitude.</summary>
        public bool VelocityFollowsPitch = false;
        public double Throttle = 1.0;             // 0..1, applied on release
        public bool RetractGear = true;
        public bool StageOnRelease = true;        // fires the next stage on release (ignites AJE engines in stage 0)
        /// <summary>Seconds to hold the vessel on rails at the start conditions while terrain and physics settle.
        /// 0 = release as soon as possible (a few physics frames).</summary>
        public double HoldSeconds = 1.0;

        public AirlaunchSettings Clone()
        {
            return (AirlaunchSettings)MemberwiseClone();
        }

        public bool Validate(AirlaunchLimits limits, out string error)
        {
            if (limits == null) limits = new AirlaunchLimits();
            error = null;

            if (!Finite(DistanceKm, Bearing, Latitude, Longitude, Altitude, Speed, Heading, Pitch, Throttle, HoldSeconds))
                error = "All values must be numbers";
            else if (Altitude < limits.MinAltitude || Altitude > limits.MaxAltitude)
                error = string.Format(CultureInfo.InvariantCulture, "Altitude must be between {0:0} and {1:0} m ASL", limits.MinAltitude, limits.MaxAltitude);
            else if (Speed < limits.MinSpeed || Speed > limits.MaxSpeed)
                error = string.Format(CultureInfo.InvariantCulture, "Speed must be between {0:0} and {1:0} m/s", limits.MinSpeed, limits.MaxSpeed);
            else if (Heading < 0 || Heading >= 360)
                error = "Heading must be in [0, 360)";
            else if (Pitch < -90 || Pitch > 90)
                error = "Pitch must be between -90 and 90 degrees";
            else if (Throttle < 0 || Throttle > 1)
                error = "Throttle must be between 0 and 1";
            else if (HoldSeconds < 0 || HoldSeconds > limits.MaxHoldSeconds)
                error = string.Format(CultureInfo.InvariantCulture, "Hold must be between 0 and {0:0} s", limits.MaxHoldSeconds);
            else if (Mode == PositionMode.LaunchSiteOffset && (DistanceKm < 0 || DistanceKm > limits.MaxDistanceKm))
                error = string.Format(CultureInfo.InvariantCulture, "Distance must be between 0 and {0:0} km", limits.MaxDistanceKm);
            else if (Mode == PositionMode.LaunchSiteOffset && (Bearing < 0 || Bearing >= 360))
                error = "Bearing must be in [0, 360)";
            // Exact poles make "heading" undefined; keep a small margin.
            else if (Mode == PositionMode.LatLon && (Latitude < -89.9 || Latitude > 89.9))
                error = "Latitude must be between -89.9 and 89.9";
            else if (Mode == PositionMode.LatLon && (Longitude < -180 || Longitude > 180))
                error = "Longitude must be between -180 and 180";

            return error == null;
        }

        private static bool Finite(params double[] values)
        {
            foreach (double v in values)
                if (double.IsNaN(v) || double.IsInfinity(v)) return false;
            return true;
        }

        public Dictionary<string, string> ToValues()
        {
            var c = CultureInfo.InvariantCulture;
            return new Dictionary<string, string>
            {
                { "name", Name ?? "" },
                { "mode", Mode.ToString() },
                { "distanceKm", DistanceKm.ToString("R", c) },
                { "bearing", Bearing.ToString("R", c) },
                { "latitude", Latitude.ToString("R", c) },
                { "longitude", Longitude.ToString("R", c) },
                { "altitude", Altitude.ToString("R", c) },
                { "speed", Speed.ToString("R", c) },
                { "heading", Heading.ToString("R", c) },
                { "pitch", Pitch.ToString("R", c) },
                { "velocityFollowsPitch", VelocityFollowsPitch.ToString() },
                { "throttle", Throttle.ToString("R", c) },
                { "retractGear", RetractGear.ToString() },
                { "stageOnRelease", StageOnRelease.ToString() },
                { "holdSeconds", HoldSeconds.ToString("R", c) },
            };
        }

        /// <summary>Builds settings from key/value pairs; missing or malformed keys keep the base value.</summary>
        public static AirlaunchSettings FromValues(IDictionary<string, string> values, AirlaunchSettings baseSettings = null)
        {
            var s = baseSettings != null ? baseSettings.Clone() : new AirlaunchSettings();
            if (values == null) return s;

            string str;
            if (values.TryGetValue("name", out str)) s.Name = str;
            if (values.TryGetValue("mode", out str))
            {
                PositionMode m;
                if (TryParseEnum(str, out m)) s.Mode = m;
            }
            s.DistanceKm = AirlaunchLimits.Read(values, "distanceKm", s.DistanceKm);
            s.Bearing = AirlaunchLimits.Read(values, "bearing", s.Bearing);
            s.Latitude = AirlaunchLimits.Read(values, "latitude", s.Latitude);
            s.Longitude = AirlaunchLimits.Read(values, "longitude", s.Longitude);
            s.Altitude = AirlaunchLimits.Read(values, "altitude", s.Altitude);
            s.Speed = AirlaunchLimits.Read(values, "speed", s.Speed);
            s.Heading = AirlaunchLimits.Read(values, "heading", s.Heading);
            s.Pitch = AirlaunchLimits.Read(values, "pitch", s.Pitch);
            s.VelocityFollowsPitch = ReadBool(values, "velocityFollowsPitch", s.VelocityFollowsPitch);
            s.Throttle = AirlaunchLimits.Read(values, "throttle", s.Throttle);
            s.RetractGear = ReadBool(values, "retractGear", s.RetractGear);
            s.StageOnRelease = ReadBool(values, "stageOnRelease", s.StageOnRelease);
            s.HoldSeconds = AirlaunchLimits.Read(values, "holdSeconds", s.HoldSeconds);
            return s;
        }

        private static bool TryParseEnum(string s, out PositionMode mode)
        {
            foreach (PositionMode m in Enum.GetValues(typeof(PositionMode)))
            {
                if (string.Equals(m.ToString(), (s ?? "").Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    mode = m;
                    return true;
                }
            }
            mode = PositionMode.LaunchSiteOffset;
            return false;
        }

        private static bool ReadBool(IDictionary<string, string> values, string key, bool fallback)
        {
            string s;
            bool b;
            if (values.TryGetValue(key, out s) && bool.TryParse((s ?? "").Trim(), out b)) return b;
            return fallback;
        }
    }
}

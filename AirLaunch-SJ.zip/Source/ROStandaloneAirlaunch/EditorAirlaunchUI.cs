// ROStandaloneAirlaunch - CC BY-NC-SA 4.0. See LICENSE.
// Editor (SPH/VAB) half of the airlaunch: a toolbar button and settings window. Replaces RP-1's
// KCT GUI_Airlaunch; instead of queueing a build, it launches through the stock editor launch path
// (EditorLogic.launchVessel), which handles crew assignment, craft saving and launch-site checks.

using System;
using System.Collections.Generic;
using System.Globalization;
using KSP.UI.Screens;
using UnityEngine;

namespace ROStandaloneAirlaunch
{
    [KSPAddon(KSPAddon.Startup.EditorAny, false)]
    public class EditorAirlaunchUI : MonoBehaviour
    {
        private const string LockId = "ROStandaloneAirlaunch_EditorLock";
        private const int WindowId = 0x524F5341; // "ROSA"
        private const float PendingTimeout = 120f;

        private static readonly string[] ModeLabels = { "Offset from launch site", "Latitude / Longitude" };

        private ApplicationLauncherButton button;
        private Texture2D icon;
        private bool showWindow;
        private Rect windowRect = new Rect(320, 90, 360, 10);
        private bool lockSet;

        private AirlaunchConfig config;
        private AirlaunchSettings settings;
        private readonly Dictionary<string, string> buffers = new Dictionary<string, string>();
        private string error;

        private void Start()
        {
            // A request left over from a launch that never happened must not hijack a later normal launch.
            AirlaunchRequest.Pending = null;

            config = AirlaunchConfig.Load();
            settings = config.LoadLastUsed();
            LoadBuffers();

            GameEvents.onGUIApplicationLauncherReady.Add(AddButton);
            GameEvents.onGUIApplicationLauncherDestroyed.Add(RemoveButton);
            GameEvents.onGameSceneLoadRequested.Add(OnSceneLoadRequested);
            GameEvents.onEditorShipModified.Add(OnShipModified);
            if (ApplicationLauncher.Ready) AddButton();
        }

        private void OnDestroy()
        {
            GameEvents.onGUIApplicationLauncherReady.Remove(AddButton);
            GameEvents.onGUIApplicationLauncherDestroyed.Remove(RemoveButton);
            GameEvents.onGameSceneLoadRequested.Remove(OnSceneLoadRequested);
            GameEvents.onEditorShipModified.Remove(OnShipModified);
            RemoveButton();
            SetLock(false);
            if (icon != null) Destroy(icon);
        }

        private void AddButton()
        {
            if (button != null || ApplicationLauncher.Instance == null) return;
            if (icon == null) icon = MakeIcon();
            button = ApplicationLauncher.Instance.AddModApplication(
                () => showWindow = true, () => { showWindow = false; SetLock(false); },
                null, null, null, null,
                ApplicationLauncher.AppScenes.SPH | ApplicationLauncher.AppScenes.VAB, icon);
        }

        private void RemoveButton()
        {
            if (button != null && ApplicationLauncher.Instance != null)
                ApplicationLauncher.Instance.RemoveModApplication(button);
            button = null;
        }

        // Only a FLIGHT scene load that follows our own launch call arms the request.
        private void OnSceneLoadRequested(GameScenes scene)
        {
            AirlaunchRequest r = AirlaunchRequest.Pending;
            if (r == null) return;
            if (scene == GameScenes.FLIGHT) r.Armed = true;
            else AirlaunchRequest.Pending = null;
        }

        private void OnShipModified(ShipConstruct ship)
        {
            // The launch we started was cancelled (for example a launch-site dialog was dismissed) and the user kept editing.
            if (AirlaunchRequest.Pending != null && !AirlaunchRequest.Pending.Armed)
                AirlaunchRequest.Pending = null;
        }

        private void Update()
        {
            AirlaunchRequest r = AirlaunchRequest.Pending;
            if (r != null && !r.Armed && Time.realtimeSinceStartup - r.CreatedRealtime > PendingTimeout)
            {
                AirlaunchRequest.Pending = null;
                Log.Info("Pending airlaunch expired without a launch");
            }
        }

        private void OnGUI()
        {
            if (!showWindow)
            {
                SetLock(false);
                return;
            }
            GUI.skin = HighLogic.Skin;
            windowRect = GUILayout.Window(WindowId, windowRect, DrawWindow, "RO Standalone Airlaunch", GUILayout.Width(360));

            Vector2 mouse = new Vector2(Input.mousePosition.x, Screen.height - Input.mousePosition.y);
            SetLock(windowRect.Contains(mouse));
        }

        private void DrawWindow(int id)
        {
            GUILayout.BeginVertical();

            if (config.Presets.Count > 0)
            {
                GUILayout.Label("Presets:");
                foreach (AirlaunchSettings p in config.Presets)
                {
                    if (GUILayout.Button(p.Name))
                    {
                        settings = p.Clone();
                        LoadBuffers();
                        error = null;
                    }
                }
            }

            GUILayout.Space(4);
            int mode = GUILayout.Toolbar((int)settings.Mode, ModeLabels);
            settings.Mode = (PositionMode)mode;

            if (settings.Mode == PositionMode.LaunchSiteOffset)
            {
                Field("Distance from launch site (km)", "distanceKm");
                Field("Bearing from launch site (deg)", "bearing");
            }
            else
            {
                Field("Latitude (deg, +N)", "latitude");
                Field("Longitude (deg, +E)", "longitude");
            }

            Field("Altitude (m above sea level)", "altitude");
            Field("Speed (m/s, surface-relative)", "speed");
            Field("Heading (deg, 90 = east)", "heading");
            Field("Pitch (deg, + = nose up)", "pitch");
            settings.VelocityFollowsPitch = GUILayout.Toggle(settings.VelocityFollowsPitch, "Velocity follows pitch (zero AoA)");

            GUILayout.BeginHorizontal();
            GUILayout.Label("Throttle on release: " + (settings.Throttle * 100).ToString("0") + "%", GUILayout.Width(170));
            settings.Throttle = Math.Round(GUILayout.HorizontalSlider((float)settings.Throttle, 0f, 1f), 2);
            GUILayout.EndHorizontal();

            settings.RetractGear = GUILayout.Toggle(settings.RetractGear, "Retract landing gear on release");
            settings.StageOnRelease = GUILayout.Toggle(settings.StageOnRelease, "Activate next stage on release (engines)");
            Field("Settle hold (s, 0 = instant)", "holdSeconds");

            GUILayout.Space(4);
            GUILayout.Label("Altitude is above sea level, not terrain. Speed is relative to the ground; Earth's rotation is added automatically.");

            if (!string.IsNullOrEmpty(error))
            {
                var style = new GUIStyle(GUI.skin.label);
                style.normal.textColor = XKCDColors.LightRed;
                GUILayout.Label(error, style);
            }

            AirlaunchRequest pending = AirlaunchRequest.Pending;
            if (pending != null && !pending.Armed)
            {
                GUILayout.Label("Waiting for the launch to be confirmed...");
                if (GUILayout.Button("Cancel airlaunch")) AirlaunchRequest.Pending = null;
            }

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Airlaunch!", GUILayout.Height(30))) TryLaunch();
            if (GUILayout.Button("Close", GUILayout.Height(30), GUILayout.Width(70)))
            {
                showWindow = false;
                if (button != null) button.SetFalse(false);
            }
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        private void Field(string label, string key)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, GUILayout.Width(210));
            buffers[key] = GUILayout.TextField(buffers.ContainsKey(key) ? buffers[key] : "", GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();
        }

        private void LoadBuffers()
        {
            buffers.Clear();
            foreach (KeyValuePair<string, string> kv in settings.ToValues())
            {
                double d;
                buffers[kv.Key] = double.TryParse(kv.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out d)
                    ? d.ToString("0.######", CultureInfo.InvariantCulture)
                    : kv.Value;
            }
        }

        private bool ApplyBuffers(out string parseError)
        {
            parseError = null;
            var values = new Dictionary<string, string>();
            foreach (string key in new[] { "distanceKm", "bearing", "latitude", "longitude", "altitude", "speed", "heading", "pitch", "holdSeconds" })
            {
                string text;
                if (!buffers.TryGetValue(key, out text)) continue;
                double d;
                if (!double.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out d) &&
                    !double.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.CurrentCulture, out d))
                {
                    parseError = "'" + text + "' is not a number (" + key + ")";
                    return false;
                }
                values[key] = d.ToString("R", CultureInfo.InvariantCulture);
            }
            settings = AirlaunchSettings.FromValues(values, settings);
            return true;
        }

        private void TryLaunch()
        {
            error = null;
            if (!ApplyBuffers(out error)) return;

            // Normalize headings so 360 and -90 are accepted.
            settings.Heading = AirlaunchMath.NormalizeDegrees(settings.Heading);
            settings.Bearing = AirlaunchMath.NormalizeDegrees(settings.Bearing);
            if (!settings.Validate(config.Limits, out error)) return;

            EditorLogic editor = EditorLogic.fetch;
            if (editor == null || editor.ship == null || editor.ship.parts == null || editor.ship.parts.Count == 0)
            {
                error = "There is no vessel to launch";
                return;
            }

            AirlaunchConfig.SaveLastUsed(settings);
            LoadBuffers();

            AirlaunchRequest.Pending = new AirlaunchRequest
            {
                Settings = settings.Clone(),
                Limits = config.Limits,
                ShipName = editor.ship.shipName,
                CreatedRealtime = Time.realtimeSinceStartup
            };

            SetLock(false);
            try
            {
                // Stock launch path from the currently selected launch site (Runway in the SPH by default).
                editor.launchVessel();
            }
            catch (Exception e)
            {
                AirlaunchRequest.Pending = null;
                error = "Launch failed: " + e.Message;
                Log.Error("launchVessel threw: " + e);
            }
        }

        private void SetLock(bool locked)
        {
            if (locked == lockSet) return;
            if (locked) InputLockManager.SetControlLock(ControlTypes.EDITOR_LOCK, LockId);
            else InputLockManager.RemoveControlLock(LockId);
            lockSet = locked;
        }

        /// <summary>Draws a simple delta-wing glyph so the mod ships without texture assets.</summary>
        private static Texture2D MakeIcon()
        {
            const int size = 38;
            var tex = new Texture2D(size, size, TextureFormat.ARGB32, false);
            var clear = new Color(0, 0, 0, 0);
            var white = Color.white;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    // Texture y=0 is the bottom row; the nose points up.
                    float fx = x - (size - 1) / 2f;
                    float fromTop = size - 1 - y;
                    bool fuselage = Mathf.Abs(fx) <= 1.5f && fromTop >= 3 && fromTop <= 34;
                    bool wing = fromTop >= 10 && fromTop <= 26 && Mathf.Abs(fx) <= (fromTop - 10) * 1.0f;
                    bool tail = fromTop >= 29 && fromTop <= 34 && Mathf.Abs(fx) <= (fromTop - 29) * 1.2f + 1;
                    tex.SetPixel(x, y, fuselage || wing || tail ? white : clear);
                }
            }
            tex.Apply();
            return tex;
        }
    }
}

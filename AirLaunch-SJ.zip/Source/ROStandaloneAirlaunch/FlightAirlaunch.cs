// ROStandaloneAirlaunch - CC BY-NC-SA 4.0. See LICENSE.
// Flight-scene half of the airlaunch. Adapted from RP-1's AirlaunchUtils.DoAirlaunchRoutine and
// ROUtils HyperEdit_Utilities.DoAirlaunch / SetOrbit / PrepVesselTeleport / ResetGroundContact
// (HyperEdit by khyperia and Ezriilc). Differences from RP-1:
//  * no KCT/RP-1 objects: settings come from AirlaunchRequest instead of KCT vessel tracking;
//  * the position is resolved from lat/lon or an offset from the actual spawn point (no KSCSwitcher lookup);
//  * pitch is supported and attitude is set on the control reference transform in world space;
//  * the settle hold flies an explicit geographic track (see AirlaunchMath.TrackAt) and is
//    configurable down to a few physics frames ("instant"), instead of a fixed 10 s countdown;
//  * after physics engages, the surface velocity is checked once and corrected if it's off.

using System;
using System.Collections;
using KSP.UI.Screens;
using UnityEngine;

namespace ROStandaloneAirlaunch
{
    [KSPAddon(KSPAddon.Startup.Flight, false)]
    public class FlightAirlaunch : MonoBehaviour
    {
        // Physics frames the vessel is held on rails at minimum, even for "instant" launches.
        // Gives the freshly spawned vessel and the destination terrain time to settle.
        private const int MinHoldFrames = 5;
        private const double VelocityTolerance = 2.0;    // m/s
        private const float UnpackTimeout = 30f;         // real seconds

        private AirlaunchRequest request;
        private Quaternion refToRoot = Quaternion.identity;

        private void Start()
        {
            request = AirlaunchRequest.Consume();
            if (request == null)
            {
                Destroy(this);
                return;
            }
            KspInterop.CheckKspVersion();
            StartCoroutine(Routine());
        }

        private IEnumerator Routine()
        {
            AirlaunchSettings s = request.Settings;
            AirlaunchLimits limits = request.Limits ?? new AirlaunchLimits();

            // 1. Wait for the launched vessel to exist and finish spawning (as RP-1 does).
            float waitStart = Time.realtimeSinceStartup;
            while (!FlightGlobals.ready || FlightGlobals.ActiveVessel == null)
            {
                if (Time.realtimeSinceStartup - waitStart > 60f)
                {
                    Cancel("the launched vessel never became active");
                    yield break;
                }
                yield return null;
            }

            Vessel v = FlightGlobals.ActiveVessel;
            Guid id = v.id;
            if (v.situation != Vessel.Situations.PRELAUNCH && v.situation != Vessel.Situations.LANDED)
            {
                Cancel("the active vessel is not a fresh launch (" + v.situation + ")");
                yield break;
            }
            if (!string.IsNullOrEmpty(request.ShipName) && v.vesselName != request.ShipName)
                Log.Warning("Vessel name '" + v.vesselName + "' differs from editor ship '" + request.ShipName + "'; continuing");

            do
            {
                yield return new WaitForFixedUpdate();
                if (!IsActive(id))
                {
                    Cancel("active vessel changed while spawning");
                    yield break;
                }
            } while (v.vesselSpawning);

            // 2. Resolve the target point and check terrain clearance.
            CelestialBody body = v.mainBody;
            double lat, lon;
            if (s.Mode == PositionMode.LatLon)
            {
                lat = s.Latitude;
                lon = s.Longitude;
            }
            else
            {
                double unusedBearing;
                AirlaunchMath.Destination(v.latitude, v.longitude, s.DistanceKm * 1000.0, s.Bearing, body.Radius,
                                          out lat, out lon, out unusedBearing);
            }

            double flightPath = s.VelocityFollowsPitch ? s.Pitch : 0.0;
            var start = new TrackPoint(lat, lon, s.Altitude, s.Heading);
            // Check both where the vessel appears and where the hold track ends (plus margin).
            TrackPoint end = AirlaunchMath.TrackAt(start, s.Speed, flightPath, body.Radius, s.HoldSeconds + 2.0);
            double terrain = Math.Max(TerrainAt(body, lat, lon), TerrainAt(body, end.Latitude, end.Longitude));
            double minAlt = Math.Min(start.Altitude, end.Altitude);
            if (minAlt < terrain + limits.TerrainClearance)
            {
                Cancel(string.Format("terrain at the target is {0:0} m; altitude must be at least {1:0} m ASL",
                                     terrain, terrain + limits.TerrainClearance));
                yield break;
            }

            Log.Info(string.Format("Airlaunch {0}: body={1} lat={2:F4} lon={3:F4} alt={4:0} m ASL, {5:0.0} m/s srf, hdg {6:0.0}, pitch {7:0.0}, hold {8:0.0} s",
                                   v.vesselName, body.bodyName, lat, lon, s.Altitude, s.Speed, s.Heading, s.Pitch, s.HoldSeconds));

            // 3. Teleport prep (HyperEdit's SetOrbit sequence).
            if (v.situation == Vessel.Situations.PRELAUNCH)
                v.situation = Vessel.Situations.LANDED;
            PrepVesselTeleport(v);
            OrbitPhysicsManager.HoldVesselUnpack(60);
            foreach (Vessel other in FlightGlobals.fetch.vessels)
                if (other != null && other.loaded) other.GoOnRails();

            Transform refTf = v.ReferenceTransform != null ? v.ReferenceTransform : v.transform;
            refToRoot = Quaternion.Inverse(refTf.rotation) * v.transform.rotation;

            // 4. Settle hold: fly the track on rails, re-applying position, velocity and attitude each tick.
            double ut0 = Planetarium.GetUniversalTime();
            int frames = 0;
            int lastCountdown = -1;
            bool maskHidden = false;
            while (true)
            {
                if (!IsActive(id))
                {
                    Cancel("active vessel changed during hold");
                    yield break;
                }
                double elapsed = Planetarium.GetUniversalTime() - ut0;
                ApplyState(v, body, AirlaunchMath.TrackAt(start, s.Speed, flightPath, body.Radius, elapsed), s, flightPath);

                // RP-1: keep PRELAUNCH while packed so Principia / persistent-rotation mods leave the vessel alone.
                v.situation = Vessel.Situations.PRELAUNCH;
                OrbitPhysicsManager.HoldVesselUnpack(2);
                KspInterop.SetPhysicsHoldExpiryOverride(v, 60);

                if (s.HoldSeconds >= 1.0)
                {
                    if (!maskHidden && frames > 0)
                    {
                        KspInterop.HideLoadingMask();
                        maskHidden = true;
                    }
                    int remaining = (int)Math.Ceiling(s.HoldSeconds - elapsed);
                    if (remaining > 0 && remaining != lastCountdown)
                    {
                        ScreenMessages.PostScreenMessage("Airlaunching in " + remaining + "...", 1f, ScreenMessageStyle.UPPER_CENTER);
                        lastCountdown = remaining;
                    }
                }

                frames++;
                if (frames >= MinHoldFrames && elapsed >= s.HoldSeconds) break;
                yield return new WaitForFixedUpdate();
            }

            // 5. Release.
            ResetGroundContact(v);
            InputLockManager.RemoveControlLock("physicsHold");
            OrbitPhysicsManager.HoldVesselUnpack(1);
            KspInterop.SetPhysicsHoldExpiryOverride(v, 1);

            float releaseStart = Time.realtimeSinceStartup;
            while (v.packed)
            {
                if (!IsActive(id))
                {
                    Cancel("active vessel changed before release");
                    yield break;
                }
                if (Time.realtimeSinceStartup - releaseStart > UnpackTimeout)
                {
                    Log.Warning("Vessel still packed after " + UnpackTimeout + " s; continuing anyway");
                    break;
                }
                // Keep it on the track until KSP actually unpacks it, so no altitude or speed is lost.
                double elapsed = Planetarium.GetUniversalTime() - ut0;
                ApplyState(v, body, AirlaunchMath.TrackAt(start, s.Speed, flightPath, body.Radius, elapsed), s, flightPath);
                v.situation = Vessel.Situations.PRELAUNCH;
                yield return new WaitForFixedUpdate();
            }
            yield return new WaitForFixedUpdate();
            if (!IsActive(id)) yield break;

            // 6. Flying: fire the situation change so trip loggers etc. notice (as RP-1 does).
            v.situation = Vessel.Situations.FLYING;
            GameEvents.onVesselSituationChange.Fire(
                new GameEvents.HostedFromToAction<Vessel, Vessel.Situations>(v, Vessel.Situations.PRELAUNCH, Vessel.Situations.FLYING));

            TrackPoint now = AirlaunchMath.TrackAt(start, s.Speed, flightPath, body.Radius, Planetarium.GetUniversalTime() - ut0);
            VerifyAndCorrectVelocity(v, body, now.Heading, flightPath, s.Speed);

            if (s.RetractGear)
                v.ActionGroups.SetGroup(KSPActionGroup.Gear, false);
            FlightInputHandler.state.mainThrottle = (float)s.Throttle;
            if (s.StageOnRelease)
                StageManager.ActivateNextStage();

            // Report what the vessel is actually doing a moment later.
            for (int i = 0; i < 10; i++) yield return new WaitForFixedUpdate();
            if (!IsActive(id)) yield break;
            LocalBasis b = KspInterop.LocalBasisAt(body, v.latitude, v.longitude);
            double srfHeading = AirlaunchMath.HeadingOf(b, KspInterop.ToVec(v.srf_velocity));
            string summary = string.Format("Airlaunch: {0:0} m ASL, {1:0.0} m/s surface, heading {2:000.0}",
                                           v.altitude, v.srfSpeed, srfHeading);
            Log.Info(summary);
            ScreenMessages.PostScreenMessage(summary, 6f, ScreenMessageStyle.UPPER_CENTER);
            Destroy(this);
        }

        /// <summary>Places the (packed) vessel at a track point with the right orbit, position and attitude.</summary>
        private void ApplyState(Vessel v, CelestialBody body, TrackPoint p, AirlaunchSettings s, double flightPath)
        {
            Vector3d worldPos = body.GetWorldSurfacePosition(p.Latitude, p.Longitude, p.Altitude);
            LocalBasis b = KspInterop.LocalBasisAt(body, p.Latitude, p.Longitude);

            // Inertial velocity = velocity of the rotating surface frame here + the requested surface velocity.
            // getRFrmVel is the same frame velocity KSP subtracts to compute srf_velocity.
            Vec3d surfVel = AirlaunchMath.SurfaceVelocity(b, p.Heading, flightPath, s.Speed);
            Vector3d obtVel = body.getRFrmVel(worldPos) + KspInterop.ToKsp(surfVel);

            // Attitude: control point "up" = nose, "forward" = belly (KSP's SPH/aircraft convention).
            Vec3d nose, belly;
            AirlaunchMath.AttitudeAxes(b, p.Heading, s.Pitch, out nose, out belly);
            Quaternion refRot = Quaternion.LookRotation((Vector3)KspInterop.ToKsp(belly), (Vector3)KspInterop.ToKsp(nose));
            v.SetRotation(refRot * refToRoot, true);

            // Orbit takes body-relative state vectors in KSP's Z-up orbital frame (.xzy swizzle), as in RP-1.
            Vector3d relPos = worldPos - body.position;
            v.orbit.UpdateFromStateVectors(relPos.xzy, obtVel.xzy, body, Planetarium.GetUniversalTime());

            // worldPos is where the centre of mass should be; offset the vessel transform accordingly.
            Vector3d localCom = (Vector3d)(v.transform.rotation * v.localCoM);
            v.SetPosition(worldPos - localCom);
        }

        private static void VerifyAndCorrectVelocity(Vessel v, CelestialBody body, double heading, double flightPath, double speed)
        {
            LocalBasis b = KspInterop.LocalBasisAt(body, v.latitude, v.longitude);
            Vector3d target = KspInterop.ToKsp(AirlaunchMath.SurfaceVelocity(b, heading, flightPath, speed));
            Vector3d error = target - v.srf_velocity;
            Log.Info(string.Format("After release: srf {0:0.00} m/s (target {1:0.00}), error {2:0.00} m/s",
                                   v.srf_velocity.magnitude, speed, error.magnitude));
            if (error.magnitude > VelocityTolerance)
            {
                v.ChangeWorldVelocity(error);
                Log.Info("Applied one-shot velocity correction of " + error.magnitude.ToString("0.00") + " m/s");
            }
        }

        private static double TerrainAt(CelestialBody body, double lat, double lon)
        {
            if (body.pqsController == null) return 0;
            try { return body.TerrainAltitude(lat, lon, false); }
            catch (Exception) { return 0; }
        }

        private static bool IsActive(Guid id)
        {
            return FlightGlobals.ActiveVessel != null && FlightGlobals.ActiveVessel.id == id;
        }

        private void Cancel(string reason)
        {
            Log.Warning("Airlaunch cancelled: " + reason);
            ScreenMessages.PostScreenMessage("Airlaunch cancelled: " + reason, 8f, ScreenMessageStyle.UPPER_CENTER);
            OrbitPhysicsManager.HoldVesselUnpack(1);
            if (FlightGlobals.ActiveVessel != null) KspInterop.SetPhysicsHoldExpiryOverride(FlightGlobals.ActiveVessel, 1);
            Destroy(this);
        }

        // From HyperEdit (via ROUtils): clear landed state and remove launch clamps before teleporting.
        private static void PrepVesselTeleport(Vessel vessel)
        {
            if (vessel.Landed) vessel.Landed = false;
            if (vessel.Splashed) vessel.Splashed = false;
            if (vessel.landedAt != string.Empty) vessel.landedAt = string.Empty;
            if (vessel.parts == null) return;
            for (int i = vessel.parts.Count - 1; i >= 0; i--)
            {
                Part part = vessel.parts[i];
                if (part.FindModuleImplementing<LaunchClamp>() != null)
                    part.Die();
            }
        }

        // From ROUtils: ground contact can stick after a teleport and confuse wheels.
        private static void ResetGroundContact(Vessel vessel)
        {
            if (vessel.parts == null) return;
            for (int i = vessel.parts.Count - 1; i >= 0; i--)
            {
                Part part = vessel.parts[i];
                part.GroundContact = false;
                if (part.Modules.Contains("KSPWheelBase"))
                    part.Modules["KSPWheelBase"].Fields.SetValue("grounded", false);
            }
        }
    }
}

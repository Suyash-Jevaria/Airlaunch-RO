// ROStandaloneAirlaunch - CC BY-NC-SA 4.0. See LICENSE.
// Loads limits, defaults and presets from PluginData/AirlaunchSettings.cfg and persists the
// last-used settings to PluginData/LastUsed.cfg. PluginData is skipped by KSP's GameDatabase,
// so these files are never parsed as part/patch configs.

using System;
using System.Collections.Generic;
using System.IO;

namespace ROStandaloneAirlaunch
{
    public class AirlaunchConfig
    {
        public const string RootNodeName = "ROSTANDALONE_AIRLAUNCH";

        public AirlaunchLimits Limits = new AirlaunchLimits();
        public AirlaunchSettings Defaults = new AirlaunchSettings();
        public readonly List<AirlaunchSettings> Presets = new List<AirlaunchSettings>();

        public static string PluginDataDir
        {
            get
            {
                // <GameData>/ROStandaloneAirlaunch/Plugins/ROStandaloneAirlaunch.dll -> ../PluginData
                try
                {
                    string dllDir = Path.GetDirectoryName(typeof(AirlaunchConfig).Assembly.Location);
                    if (!string.IsNullOrEmpty(dllDir))
                        return Path.GetFullPath(Path.Combine(dllDir, Path.Combine("..", "PluginData")));
                }
                catch (Exception) { }
                return Path.Combine(KSPUtil.ApplicationRootPath, "GameData/ROStandaloneAirlaunch/PluginData");
            }
        }

        public static string SettingsPath { get { return Path.Combine(PluginDataDir, "AirlaunchSettings.cfg"); } }
        public static string LastUsedPath { get { return Path.Combine(PluginDataDir, "LastUsed.cfg"); } }

        public static AirlaunchConfig Load()
        {
            var cfg = new AirlaunchConfig();
            ConfigNode root = LoadRoot(SettingsPath);
            if (root == null)
            {
                Log.Warning("Settings file not found or invalid, using built-in defaults: " + SettingsPath);
                cfg.Presets.Add(AcceptancePreset());
                return cfg;
            }

            ConfigNode limits = root.GetNode("LIMITS");
            if (limits != null) cfg.Limits = AirlaunchLimits.FromValues(ToDict(limits));

            ConfigNode defaults = root.GetNode("DEFAULTS");
            if (defaults != null) cfg.Defaults = AirlaunchSettings.FromValues(ToDict(defaults));

            foreach (ConfigNode p in root.GetNodes("PRESET"))
            {
                var preset = AirlaunchSettings.FromValues(ToDict(p), cfg.Defaults);
                if (string.IsNullOrEmpty(preset.Name)) preset.Name = "Preset " + (cfg.Presets.Count + 1);
                cfg.Presets.Add(preset);
            }
            if (cfg.Presets.Count == 0) cfg.Presets.Add(AcceptancePreset());
            return cfg;
        }

        /// <summary>Last settings used, layered over the configured defaults.</summary>
        public AirlaunchSettings LoadLastUsed()
        {
            ConfigNode root = LoadRoot(LastUsedPath);
            ConfigNode n = root != null ? root.GetNode("LAST_USED") : null;
            return n != null ? AirlaunchSettings.FromValues(ToDict(n), Defaults) : Defaults.Clone();
        }

        public static void SaveLastUsed(AirlaunchSettings s)
        {
            try
            {
                Directory.CreateDirectory(PluginDataDir);
                var outer = new ConfigNode();
                var root = outer.AddNode(RootNodeName);
                var n = root.AddNode("LAST_USED");
                foreach (KeyValuePair<string, string> kv in s.ToValues())
                    n.AddValue(kv.Key, kv.Value);
                outer.Save(LastUsedPath);
            }
            catch (Exception e)
            {
                Log.Warning("Could not save last-used settings: " + e.Message);
            }
        }

        private static ConfigNode LoadRoot(string path)
        {
            try
            {
                if (!File.Exists(path)) return null;
                ConfigNode file = ConfigNode.Load(path);
                return file != null ? file.GetNode(RootNodeName) : null;
            }
            catch (Exception e)
            {
                Log.Warning("Failed to read " + path + ": " + e.Message);
                return null;
            }
        }

        private static Dictionary<string, string> ToDict(ConfigNode node)
        {
            var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (ConfigNode.Value v in node.values)
                d[v.name] = v.value;
            return d;
        }

        private static AirlaunchSettings AcceptancePreset()
        {
            return new AirlaunchSettings
            {
                Name = "Acceptance test: 12 km / 350 m/s / 090",
                Altitude = 12000, Speed = 350, Heading = 90, Pitch = 0
            };
        }
    }

    /// <summary>
    /// Settings handed from the editor to the flight scene. Replaces RP-1's KCT vessel tracking.
    /// Static, so it survives the scene change; it's consumed exactly once.
    /// </summary>
    public class AirlaunchRequest
    {
        public AirlaunchSettings Settings;
        public AirlaunchLimits Limits;
        public string ShipName;
        public float CreatedRealtime;
        /// <summary>Set when KSP actually begins loading the flight scene for this launch.</summary>
        public bool Armed;

        // A request that never turned into a flight scene within this window is stale.
        public const float MaxAgeSeconds = 600f;

        public static AirlaunchRequest Pending;

        public static AirlaunchRequest Consume()
        {
            AirlaunchRequest r = Pending;
            Pending = null;
            if (r == null || !r.Armed) return null;
            if (UnityEngine.Time.realtimeSinceStartup - r.CreatedRealtime > MaxAgeSeconds) return null;
            return r;
        }
    }

    internal static class Log
    {
        private const string Prefix = "[ROStandaloneAirlaunch] ";
        public static void Info(string msg) { UnityEngine.Debug.Log(Prefix + msg); }
        public static void Warning(string msg) { UnityEngine.Debug.LogWarning(Prefix + msg); }
        public static void Error(string msg) { UnityEngine.Debug.LogError(Prefix + msg); }
    }
}

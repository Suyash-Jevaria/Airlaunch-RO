// ROStandaloneAirlaunch - standalone airlaunch for KSP 1.12 / RSS / RO.
// Licensed CC BY-NC-SA 4.0. Approach adapted from RP-1 (KSP-RO/RP-1, AirlaunchUtils.cs) and
// ROUtils HyperEdit_Utilities.DoAirlaunch (originally from HyperEdit by khyperia and Ezriilc).
//
// This file is deliberately free of KSP and Unity types so it can be unit tested outside the game.

using System;

namespace ROStandaloneAirlaunch
{
    /// <summary>Minimal double-precision vector used by the pure math layer.</summary>
    public struct Vec3d
    {
        public double X, Y, Z;

        public Vec3d(double x, double y, double z) { X = x; Y = y; Z = z; }

        public static readonly Vec3d Zero = new Vec3d(0, 0, 0);

        public double Magnitude { get { return Math.Sqrt(X * X + Y * Y + Z * Z); } }

        public Vec3d Normalized
        {
            get
            {
                double m = Magnitude;
                return m > 0 ? this / m : Zero;
            }
        }

        public static Vec3d operator +(Vec3d a, Vec3d b) { return new Vec3d(a.X + b.X, a.Y + b.Y, a.Z + b.Z); }
        public static Vec3d operator -(Vec3d a, Vec3d b) { return new Vec3d(a.X - b.X, a.Y - b.Y, a.Z - b.Z); }
        public static Vec3d operator -(Vec3d a) { return new Vec3d(-a.X, -a.Y, -a.Z); }
        public static Vec3d operator *(Vec3d a, double s) { return new Vec3d(a.X * s, a.Y * s, a.Z * s); }
        public static Vec3d operator *(double s, Vec3d a) { return a * s; }
        public static Vec3d operator /(Vec3d a, double s) { return new Vec3d(a.X / s, a.Y / s, a.Z / s); }

        public static double Dot(Vec3d a, Vec3d b) { return a.X * b.X + a.Y * b.Y + a.Z * b.Z; }

        public static Vec3d Cross(Vec3d a, Vec3d b)
        {
            return new Vec3d(a.Y * b.Z - a.Z * b.Y, a.Z * b.X - a.X * b.Z, a.X * b.Y - a.Y * b.X);
        }

        public override string ToString() { return string.Format("({0:F3}, {1:F3}, {2:F3})", X, Y, Z); }
    }

    /// <summary>Local East/North/Up unit vectors at a point on a body.</summary>
    public struct LocalBasis
    {
        public Vec3d East, North, Up;

        public LocalBasis(Vec3d east, Vec3d north, Vec3d up) { East = east; North = north; Up = up; }
    }

    /// <summary>Geographic point plus heading, used for the hold-phase track.</summary>
    public struct TrackPoint
    {
        public double Latitude, Longitude, Altitude, Heading;

        public TrackPoint(double lat, double lon, double alt, double heading)
        {
            Latitude = lat; Longitude = lon; Altitude = alt; Heading = heading;
        }
    }

    public static class AirlaunchMath
    {
        public const double Deg2Rad = Math.PI / 180.0;
        public const double Rad2Deg = 180.0 / Math.PI;

        // Finite-difference step for the local basis. Small enough to be local, large enough
        // to stay well above double precision noise at Earth-sized radii.
        private const double BasisStepDeg = 1e-4;

        /// <summary>
        /// Builds East/North/Up from a body's own lat/lon -> world-position mapping.
        /// Using the body's mapping (rather than a hard-coded cross-product convention) means
        /// "north" is exactly increasing latitude and "east" exactly increasing longitude in
        /// whatever handedness the caller's coordinate system has. That's the same definition
        /// KSP's navball uses.
        /// </summary>
        public static LocalBasis ComputeLocalBasis(Func<double, double, Vec3d> surfacePosition, Vec3d bodyCenter, double latDeg, double lonDeg)
        {
            Vec3d p = surfacePosition(latDeg, lonDeg);
            Vec3d up = (p - bodyCenter).Normalized;

            // Step away from the pole so the latitude difference stays well defined.
            double dLat = latDeg > 89.0 ? -BasisStepDeg : BasisStepDeg;
            Vec3d north = (surfacePosition(latDeg + dLat, lonDeg) - p) * Math.Sign(dLat);
            north = (north - up * Vec3d.Dot(north, up)).Normalized;

            Vec3d east = surfacePosition(latDeg, lonDeg + BasisStepDeg) - p;
            east = east - up * Vec3d.Dot(east, up) - north * Vec3d.Dot(east, north);
            east = east.Normalized;

            return new LocalBasis(east, north, up);
        }

        /// <summary>Horizontal unit vector for a compass heading (0 = north, 90 = east).</summary>
        public static Vec3d HeadingVector(LocalBasis b, double headingDeg)
        {
            double h = headingDeg * Deg2Rad;
            return (b.East * Math.Sin(h) + b.North * Math.Cos(h)).Normalized;
        }

        /// <summary>
        /// Surface-relative velocity vector: speed along the heading, raised by the flight-path angle.
        /// </summary>
        public static Vec3d SurfaceVelocity(LocalBasis b, double headingDeg, double flightPathDeg, double speed)
        {
            double g = flightPathDeg * Deg2Rad;
            return (HeadingVector(b, headingDeg) * Math.Cos(g) + b.Up * Math.Sin(g)) * speed;
        }

        /// <summary>
        /// Inertial (orbital) velocity = rotating-frame velocity at the point + surface-relative velocity.
        /// This is what makes the launch account for the planet's rotation: on RSS Earth near KSC an
        /// eastbound 350 m/s surface speed becomes roughly 350 + 408 m/s of orbital speed.
        /// </summary>
        public static Vec3d InertialVelocity(Vec3d frameVelocity, Vec3d surfaceVelocity)
        {
            return frameVelocity + surfaceVelocity;
        }

        /// <summary>
        /// Attitude axes for heading/pitch with zero roll. Nose points along the heading, raised by pitch.
        /// "Belly" is the aircraft's ventral direction (perpendicular to the nose, pointing towards the ground).
        /// </summary>
        public static void AttitudeAxes(LocalBasis b, double headingDeg, double pitchDeg, out Vec3d nose, out Vec3d belly)
        {
            double p = pitchDeg * Deg2Rad;
            Vec3d h = HeadingVector(b, headingDeg);
            nose = (h * Math.Cos(p) + b.Up * Math.Sin(p)).Normalized;
            belly = (h * Math.Sin(p) - b.Up * Math.Cos(p)).Normalized;
        }

        /// <summary>Compass heading of a vector in the local basis, in [0, 360).</summary>
        public static double HeadingOf(LocalBasis b, Vec3d v)
        {
            double hdg = Math.Atan2(Vec3d.Dot(v, b.East), Vec3d.Dot(v, b.North)) * Rad2Deg;
            return NormalizeDegrees(hdg);
        }

        public static double NormalizeDegrees(double deg)
        {
            deg %= 360.0;
            if (deg < 0) deg += 360.0;
            return deg;
        }

        /// <summary>Wraps a longitude to (-180, 180].</summary>
        public static double NormalizeLongitude(double lonDeg)
        {
            double l = NormalizeDegrees(lonDeg + 180.0) - 180.0;
            return l == -180.0 ? 180.0 : l;
        }

        /// <summary>Smallest signed difference a - b between two headings, in (-180, 180].</summary>
        public static double HeadingDifference(double aDeg, double bDeg)
        {
            double d = NormalizeDegrees(aDeg - bDeg);
            return d > 180.0 ? d - 360.0 : d;
        }

        /// <summary>
        /// Great-circle destination from a start point, given distance and initial bearing.
        /// Also returns the final bearing at the destination (the heading of the great circle there).
        /// </summary>
        public static void Destination(double latDeg, double lonDeg, double distance, double bearingDeg, double radius,
                                       out double destLatDeg, out double destLonDeg, out double finalBearingDeg)
        {
            double phi1 = latDeg * Deg2Rad;
            double lambda1 = lonDeg * Deg2Rad;
            double theta = bearingDeg * Deg2Rad;
            double delta = distance / radius;

            double sinPhi2 = Math.Sin(phi1) * Math.Cos(delta) + Math.Cos(phi1) * Math.Sin(delta) * Math.Cos(theta);
            sinPhi2 = Math.Max(-1.0, Math.Min(1.0, sinPhi2));
            double phi2 = Math.Asin(sinPhi2);
            double lambda2 = lambda1 + Math.Atan2(Math.Sin(theta) * Math.Sin(delta) * Math.Cos(phi1),
                                                  Math.Cos(delta) - Math.Sin(phi1) * sinPhi2);

            destLatDeg = phi2 * Rad2Deg;
            destLonDeg = NormalizeLongitude(lambda2 * Rad2Deg);

            if (distance <= 0)
            {
                finalBearingDeg = NormalizeDegrees(bearingDeg);
                return;
            }
            // Final bearing = reverse of the initial bearing from destination back to start.
            finalBearingDeg = NormalizeDegrees(InitialBearing(destLatDeg, destLonDeg, latDeg, lonDeg) + 180.0);
        }

        public static double InitialBearing(double lat1Deg, double lon1Deg, double lat2Deg, double lon2Deg)
        {
            double phi1 = lat1Deg * Deg2Rad, phi2 = lat2Deg * Deg2Rad;
            double dLambda = (lon2Deg - lon1Deg) * Deg2Rad;
            double y = Math.Sin(dLambda) * Math.Cos(phi2);
            double x = Math.Cos(phi1) * Math.Sin(phi2) - Math.Sin(phi1) * Math.Cos(phi2) * Math.Cos(dLambda);
            return NormalizeDegrees(Math.Atan2(y, x) * Rad2Deg);
        }

        /// <summary>Great-circle (haversine) distance on a sphere of the given radius.</summary>
        public static double GreatCircleDistance(double lat1Deg, double lon1Deg, double lat2Deg, double lon2Deg, double radius)
        {
            double phi1 = lat1Deg * Deg2Rad, phi2 = lat2Deg * Deg2Rad;
            double dPhi = phi2 - phi1;
            double dLambda = (lon2Deg - lon1Deg) * Deg2Rad;
            double a = Math.Sin(dPhi / 2) * Math.Sin(dPhi / 2) +
                       Math.Cos(phi1) * Math.Cos(phi2) * Math.Sin(dLambda / 2) * Math.Sin(dLambda / 2);
            return 2 * radius * Math.Atan2(Math.Sqrt(a), Math.Sqrt(Math.Max(0, 1 - a)));
        }

        /// <summary>
        /// Where the vessel should be <paramref name="elapsed"/> seconds into the settle hold.
        /// While held on rails the vessel flies a straight, constant-speed, surface-relative track,
        /// the way a real carrier aircraft would. This replaces RP-1's per-frame orbit patching,
        /// which assumes KSP's inverse-rotation frame, with an explicit geographic track that's
        /// valid in either frame.
        /// </summary>
        public static TrackPoint TrackAt(TrackPoint start, double speed, double flightPathDeg, double bodyRadius, double elapsed)
        {
            double g = flightPathDeg * Deg2Rad;
            double horizontal = speed * Math.Cos(g) * elapsed;
            double alt = start.Altitude + speed * Math.Sin(g) * elapsed;
            // Ground track measured at flight altitude: angular distance = arc / (R + h).
            double lat, lon, hdg;
            Destination(start.Latitude, start.Longitude, horizontal, start.Heading, bodyRadius + start.Altitude,
                        out lat, out lon, out hdg);
            return new TrackPoint(lat, lon, alt, hdg);
        }
    }
}

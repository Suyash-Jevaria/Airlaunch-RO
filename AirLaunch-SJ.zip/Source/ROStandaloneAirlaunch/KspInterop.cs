// ROStandaloneAirlaunch - CC BY-NC-SA 4.0. See LICENSE.
// Conversions between the pure math layer and KSP/Unity types, plus guarded access to the
// few non-public KSP members RP-1 uses. RP-1 compiles against a publicized Assembly-CSharp;
// this mod compiles against the stock one and reaches them by reflection instead.
// Every call degrades gracefully if a member is missing.

using System;
using System.Reflection;
using UnityEngine;

namespace ROStandaloneAirlaunch
{
    internal static class KspInterop
    {
        public static Vec3d ToVec(Vector3d v) { return new Vec3d(v.x, v.y, v.z); }
        public static Vector3d ToKsp(Vec3d v) { return new Vector3d(v.X, v.Y, v.Z); }

        /// <summary>East/North/Up at lat/lon in Unity world space, derived from the body's own surface mapping.</summary>
        public static LocalBasis LocalBasisAt(CelestialBody body, double lat, double lon)
        {
            return AirlaunchMath.ComputeLocalBasis(
                (la, lo) => ToVec(body.GetWorldSurfacePosition(la, lo, 0)),
                ToVec(body.position), lat, lon);
        }

        // --- Vessel.SetPhysicsHoldExpiryOverride(int) : non-public in stock 1.12 ---
        private static readonly MethodInfo holdOverrideMethod =
            typeof(Vessel).GetMethod("SetPhysicsHoldExpiryOverride", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                                     null, new[] { typeof(int) }, null);
        private static bool holdOverrideWarned;

        public static void SetPhysicsHoldExpiryOverride(Vessel v, int frames)
        {
            if (v == null) return;
            if (holdOverrideMethod == null)
            {
                if (!holdOverrideWarned) Log.Warning("Vessel.SetPhysicsHoldExpiryOverride not found; relying on OrbitPhysicsManager.HoldVesselUnpack only");
                holdOverrideWarned = true;
                return;
            }
            try { holdOverrideMethod.Invoke(v, new object[] { frames }); }
            catch (Exception e)
            {
                if (!holdOverrideWarned) Log.Warning("SetPhysicsHoldExpiryOverride failed: " + e.Message);
                holdOverrideWarned = true;
            }
        }

        // --- LoadingBufferMask.Instance.Hide() : both non-public ---
        public static void HideLoadingMask()
        {
            try
            {
                Type t = typeof(Vessel).Assembly.GetType("LoadingBufferMask");
                if (t == null) return;
                FieldInfo inst = t.GetField("Instance", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
                object mask = inst != null ? inst.GetValue(null) : null;
                if (mask == null) return;
                MethodInfo hide = t.GetMethod("Hide", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, Type.EmptyTypes, null);
                if (hide != null) hide.Invoke(mask, null);
                var mb = mask as MonoBehaviour;
                if (mb != null) mb.StopCoroutine("ShowDuration");
            }
            catch (Exception e)
            {
                Log.Warning("Could not hide loading mask: " + e.Message);
            }
        }

        /// <summary>Logs the running KSP version and warns if it's not 1.12.x.</summary>
        public static void CheckKspVersion()
        {
            try
            {
                int major = Versioning.version_major, minor = Versioning.version_minor, rev = Versioning.Revision;
                Log.Info(string.Format("Running on KSP {0}.{1}.{2}", major, minor, rev));
                if (major != 1 || minor != 12)
                    Log.Warning("Built and tested against KSP 1.12.x APIs; this version may not work.");
            }
            catch (Exception e)
            {
                Log.Warning("Could not read KSP version: " + e.Message);
            }
        }
    }
}
